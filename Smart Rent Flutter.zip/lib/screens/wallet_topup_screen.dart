import 'package:flutter/material.dart';
import 'package:moyasar/moyasar.dart' as moyasar;
import '../config/env.dart';
import '../services/payment_service.dart';

class WalletTopupScreen extends StatefulWidget {
  const WalletTopupScreen({Key? key}) : super(key: key);
  
  @override
  State<WalletTopupScreen> createState() => _WalletTopupScreenState();
}

class _WalletTopupScreenState extends State<WalletTopupScreen> {
  final _paymentService = PaymentService();
  
  String? _publishableKey;
  double _walletBalance = 0;
  int _selectedAmount = 5000; // 50 SAR in halalas
  bool _isLoading = true;
  bool _isProcessing = false;
  
  final List<int> _presetAmounts = [
    1000,  // 10 SAR
    2500,  // 25 SAR
    5000,  // 50 SAR
    10000, // 100 SAR
    25000, // 250 SAR
    50000, // 500 SAR
  ];
  
  @override
  void initState() {
    super.initState();
    _loadData();
  }
  
  Future<void> _loadData() async {
    try {
      final config = await _paymentService.getConfig();
      final wallet = await _paymentService.getWalletBalance();
      
      setState(() {
        _publishableKey = config.publishableKey;
        _walletBalance = wallet.balance;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      _showError('Failed to load data: $e');
    }
  }
  
  void _onPaymentResult(moyasar.PaymentResponse result) async {
    if (result.status == moyasar.PaymentStatus.paid) {
      // Payment successful via Moyasar
      // Now send to our API
      await _processTopup(result);
    } else if (result.status == moyasar.PaymentStatus.failed) {
      _showError('Payment failed');
    }
  }

  Future<void> _processTopup(moyasar.PaymentResponse moyasarResult) async {
    setState(() => _isProcessing = true);
    
    try {
      // Extract token from Moyasar response
      final token = moyasarResult.id; // Moyasar payment ID acts as token
      
      // For direct Moyasar SDK payments, you may need to verify the payment
      // instead of creating a new one. Check your backend implementation.
      
      // If using form token approach:
      final payment = await _paymentService.topupWallet(
        token: token,
        amount: _selectedAmount,
        currency: Env.currency,
      );
      
      if (payment.isPaid) {
        _showSuccess('Wallet topped up successfully!');
        await _loadData(); // Refresh balance
      } else if (payment.requires3DS) {
        // Handle 3DS redirect if needed
        await _handle3DS(payment.paymentUrl!, payment.paymentId);
      }
    } catch (e) {
      _showError('Top-up failed: $e');
    } finally {
      setState(() => _isProcessing = false);
    }
  }
  
  Future<void> _handle3DS(String url, int paymentId) async {
    // Launch WebView for 3DS
    // Note: You might need a WebView screen for this.
    // For now, we'll assume a simple WebView implementation or external browser
    // final result = await Navigator.push(
    //   context,
    //   MaterialPageRoute(
    //     builder: (_) => Payment3DSScreen(url: url),
    //   ),
    // );
    
    // After 3DS, verify payment
    // This part needs a proper 3DS handling screen which is not fully detailed in the snippet
    // but implied. I will add a TODO or a simple placeholder.
    
    _showError('3DS Verification not implemented in this snippet');
    
    // final payment = await _paymentService.verifyPayment(paymentId);
    
    // if (payment.isPaid) {
    //   _showSuccess('Wallet topped up successfully!');
    //   await _loadData();
    // } else {
    //   _showError('Payment verification failed');
    // }
  }
  
  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }
  
  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.green),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    
    return Scaffold(
      appBar: AppBar(title: const Text('Top-up Wallet')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Current Balance Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    const Icon(Icons.account_balance_wallet, size: 48),
                    const SizedBox(width: 16),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Current Balance',
                            style: TextStyle(color: Colors.grey)),
                        Text(
                          '${_walletBalance.toStringAsFixed(2)} ${Env.currency}',
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 24),
            const Text('Select Amount',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            
            // Preset Amount Buttons
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _presetAmounts.map((amount) {
                final isSelected = _selectedAmount == amount;
                return ChoiceChip(
                  label: Text('${(amount / 100).toStringAsFixed(0)} ${Env.currency}'),
                  selected: isSelected,
                  onSelected: (_) => setState(() => _selectedAmount = amount),
                );
              }).toList(),
            ),
            
            const SizedBox(height: 24),
            
            // Payment Form
            if (_publishableKey != null) ...[
              const Text('Payment Details',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              
              if (_isProcessing)
                const Center(child: CircularProgressIndicator())
              else
                moyasar.CreditCard(
                  config: moyasar.PaymentConfig(
                    publishableApiKey: _publishableKey!,
                    amount: _selectedAmount,
                    description: 'Wallet Top-up',
                    metadata: {'type': 'topup'},
                    creditCard: moyasar.CreditCardConfig(saveCard: false, manual: false),
                  ),
                  onPaymentResult: _onPaymentResult,
                ),
            ],
          ],
        ),
      ),
    );
  }
}
