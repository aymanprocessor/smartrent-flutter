part of 'history_screen.dart';

class HistoryMobileScreen extends GetView<HistoryController> {
  const HistoryMobileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        Strings.history,
        centerTitle: false,
        showBackButton: true,
      ),
      body: Obx(
        () => controller.isLoading ? const HistoryShimmer() : _bodyWidget(),
      ),
    );
  }

  _bodyWidget() {
    return SafeArea(
      child: controller.historyList.isNotEmpty
          ? _HistoryListView(controller: controller)
          : EmptyDataWidget(),
    );
  }
}

class _HistoryListView extends StatefulWidget {
  final HistoryController controller;

  const _HistoryListView({required this.controller});

  @override
  State<_HistoryListView> createState() => _HistoryListViewState();
}

class _HistoryListViewState extends State<_HistoryListView> {
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 200) {
      if (widget.controller.hasMore && !widget.controller.isLoadingMore) {
        widget.controller.loadMore();
      }
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: widget.controller.refresh,
      color: CustomColor.primary,
      child: Padding(
        padding: EdgeInsets.only(top: Dimensions.verticalSize),
        child: Obx(
          () => ListView.builder(
            controller: _scrollController,
            itemCount:
                widget.controller.historyList.length +
                (widget.controller.isLoadingMore ? 1 : 0),
            itemBuilder: (context, index) {
              if (index == widget.controller.historyList.length) {
                return Center(
                  child: Padding(
                    padding: EdgeInsets.all(Dimensions.heightSize),
                    child: CircularProgressIndicator(
                      color: CustomColor.primary,
                    ),
                  ),
                );
              }

              if (index >= widget.controller.historyList.length) {
                return SizedBox.shrink();
              }

              return HistoryCard(index);
            },
          ),
        ),
      ),
    );
  }
}
