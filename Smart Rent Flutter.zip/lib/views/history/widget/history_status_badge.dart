part of '../screen/history_screen.dart';

class HistoryStatusBadge extends StatelessWidget {
  final int status;

  const HistoryStatusBadge({
    required this.status,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: Dimensions.horizontalSize * 0.5,
        vertical: Dimensions.verticalSize * 0.25,
      ),
      decoration: BoxDecoration(
        color: _getStatusColor().withOpacity(0.15),
        borderRadius: BorderRadius.circular(Dimensions.radius * 0.4),
        border: Border.all(
          color: _getStatusColor(),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: _getStatusColor(),
              shape: BoxShape.circle,
            ),
          ),
          Sizes.width.v5,
          TextWidget(
            _getStatusText(),
            typographyStyle: TypographyStyle.bodySmall,
            color: _getStatusColor(),
            fontWeight: FontWeight.w600,
          ),
        ],
      ),
    );
  }

  Color _getStatusColor() {
    switch (status) {
      case 1:
        return Colors.orange;
      case 2:
        return Colors.blue;
      case 3:
        return CustomColor.primary;
      case 4:
        return CustomColor.rejected;
      default:
        return Colors.grey;
    }
  }

  String _getStatusText() {
    switch (status) {
      case 1:
        return Strings.pending;
      case 2:
        return Strings.ongoing;
      case 3:
        return Strings.complete;
      case 4:
        return Strings.reject;
      default:
        return 'Unknown';
    }
  }
}
