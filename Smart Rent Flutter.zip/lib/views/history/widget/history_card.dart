part of '../screen/history_screen.dart';

class HistoryCard extends GetView<HistoryController> {
  final int index;

  const HistoryCard(this.index, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final info = controller.historyList[index];
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: Dimensions.verticalSize * 0.6,
        horizontal: Dimensions.defaultHorizontalSize,
      ),
      decoration: BoxDecoration(
        color: CustomColor.whiteColor,
        borderRadius: BorderRadius.circular(Dimensions.radius * 1.2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: InkWell(
        onTap: () {
          Get.toNamed(
            '/historyDetailScreen',
            arguments: {'history': info},
          );
        },
        borderRadius: BorderRadius.circular(Dimensions.radius * 1.2),
        child: Padding(
          padding: EdgeInsets.all(Dimensions.paddingSize),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header: Car Type & Status
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Car Type Badge
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: Dimensions.horizontalSize * 0.5,
                      vertical: Dimensions.verticalSize * 0.2,
                    ),
                    decoration: BoxDecoration(
                      color: CustomColor.primary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(Dimensions.radius * 0.4),
                    ),
                    child: TextWidget(
                      info.cars.carType ?? 'Car',
                      typographyStyle: TypographyStyle.bodySmall,
                      color: CustomColor.primary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  // Status Badge
                  HistoryStatusBadge(status: info.status),
                ],
              ),
              Sizes.height.v10,
              
              // Car Model
              Row(
                children: [
                  Icon(
                    Icons.directions_car,
                    size: 24,
                    color: CustomColor.typography,
                  ),
                  Sizes.width.v10,
                  Expanded(
                    child: TextWidget(
                      info.cars.carModel ?? 'Unknown Model',
                      typographyStyle: TypographyStyle.titleMedium,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              Sizes.height.v10,
              
              // Car Image and Number
              Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(Dimensions.radius * 0.8),
                    child: Container(
                      width: 70,
                      height: 50,
                      color: CustomColor.primary.withOpacity(0.1),
                      child: Icon(
                        Icons.directions_car,
                        size: 30,
                        color: CustomColor.primary.withOpacity(0.5),
                      ),
                    ),
                  ),
                  Sizes.width.v10,
                  Expanded(
                    child: TextWidget(
                      info.cars.carNumber ?? 'N/A',
                      typographyStyle: TypographyStyle.bodySmall,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              Sizes.height.v15,
              
              // Vendor Information Section
              if (info.vendorInfo != null && 
                  (info.vendorInfo?.fullname?.isNotEmpty ?? false))
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Divider(
                      height: 1,
                      color: CustomColor.typography.withOpacity(0.1),
                    ),
                    Sizes.height.v10,
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Vendor Image
                        if (info.vendorInfo?.image != null && 
                            info.vendorInfo!.image!.isNotEmpty)
                          ClipRRect(
                            borderRadius: BorderRadius.circular(Dimensions.radius * 0.6),
                            child: Image.network(
                              info.vendorInfo!.image!,
                              width: 50,
                              height: 50,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                                return Container(
                                  width: 50,
                                  height: 50,
                                  decoration: BoxDecoration(
                                    color: CustomColor.primary.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(Dimensions.radius * 0.6),
                                  ),
                                  child: Icon(
                                    Icons.person,
                                    size: 24,
                                    color: CustomColor.primary,
                                  ),
                                );
                              },
                            ),
                          )
                        else
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              color: CustomColor.primary.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(Dimensions.radius * 0.6),
                            ),
                            child: Icon(
                              Icons.person,
                              size: 24,
                              color: CustomColor.primary,
                            ),
                          ),
                        Sizes.width.v10,
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              TextWidget(
                                'Vendor',
                                typographyStyle: TypographyStyle.bodySmall,
                                color: CustomColor.typography.withOpacity(0.6),
                                fontWeight: FontWeight.w500,
                              ),
                              Sizes.height.v5,
                              TextWidget(
                                info.vendorInfo?.fullname ?? 'N/A',
                                typographyStyle: TypographyStyle.titleSmall,
                                fontWeight: FontWeight.w600,
                              ),
                              if (info.vendorInfo?.email != null && 
                                  info.vendorInfo!.email!.isNotEmpty)
                                Padding(
                                  padding: EdgeInsets.only(top: Dimensions.verticalSize * 0.2),
                                  child: TextWidget(
                                    info.vendorInfo!.email!,
                                    typographyStyle: TypographyStyle.bodySmall,
                                    color: CustomColor.typography.withOpacity(0.6),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    Sizes.height.v10,
                    Divider(
                      height: 1,
                      color: CustomColor.typography.withOpacity(0.1),
                    ),
                    Sizes.height.v10,
                  ],
                ),
              
              // Bottom Section: Date & View Details Button
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Booking Date
                  Row(
                    children: [
                      Icon(
                        Icons.calendar_today,
                        size: 16,
                        color: CustomColor.typography.withOpacity(0.6),
                      ),
                      Sizes.width.v5,
                      TextWidget(
                        _formatDate(info.pickupDate),
                        typographyStyle: TypographyStyle.bodySmall,
                        color: CustomColor.typography.withOpacity(0.8),
                      ),
                    ],
                  ),
                  
                  // View Details Button
                  InkWell(
                    onTap: () {
                      Get.toNamed(
                        '/historyDetailScreen',
                        arguments: {'history': info},
                      );
                    },
                    child: Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: Dimensions.horizontalSize * 0.6,
                        vertical: Dimensions.verticalSize * 0.3,
                      ),
                      decoration: BoxDecoration(
                        color: CustomColor.primary,
                        borderRadius: BorderRadius.circular(Dimensions.radius * 0.5),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          TextWidget(
                            'View Details',
                            typographyStyle: TypographyStyle.bodySmall,
                            color: CustomColor.whiteColor,
                            fontWeight: FontWeight.w600,
                          ),
                          Sizes.width.v5,
                          Icon(
                            Icons.arrow_forward_ios,
                            size: 10,
                            color: CustomColor.whiteColor,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(IntProperty('index', index));
  }
}
