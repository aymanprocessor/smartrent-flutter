import 'package:carbo/views/history/model/history_model.dart';
import 'package:get/get.dart';

import '../../../base/api/endpoint/api_endpoint.dart';
import '../../../base/api/method/request_process.dart';

class HistoryController extends GetxController {
  final List<RxBool> isExpanded = List.generate(1000, (_) => false.obs);

  void toggleCardExpansion(int index) {
    for (int i = 0; i < isExpanded.length; i++) {
      if (i != index) {
        isExpanded[i].value = false;
      }
    }
    isExpanded[index].toggle();
  }

  @override
  void onInit() {
    super.onInit();
    getHistoryInfo();
  }

  var historyList = <History>[].obs;

  final _isLoading = false.obs;
  final _isLoadingMore = false.obs;

  bool get isLoading => _isLoading.value;
  bool get isLoadingMore => _isLoadingMore.value;

  // Pagination variables
  int _currentPage = 1;
  int _perPage = 3;
  bool _hasMore = true;

  bool get hasMore => _hasMore;

  late HistoryModel _historyModel;

  HistoryModel get historyModel => _historyModel;

  Future<HistoryModel?> getHistoryInfo({bool isLoadMore = false}) async {
    if (isLoadMore) {
      if (!_hasMore || _isLoadingMore.value) return null;
      _isLoadingMore.value = true;
    }

    return RequestProcess().request<HistoryModel>(
      fromJson: HistoryModel.fromJson,
      apiEndpoint: ApiEndpoint.history,
      queryParams: {
        'page': _currentPage.toString(),
        'per_page': _perPage.toString(),
      },
      isLoading: isLoadMore ? _isLoadingMore : _isLoading,
      showErrorMessage: true,
      onSuccess: (value) {
        if (value == null) {
          _hasMore = false;
          if (isLoadMore) _isLoadingMore.value = false;
          return;
        }

        _historyModel = value;

        // Check if we have pagination info in the response
        if (value.data.history.isEmpty) {
          _hasMore = false;
          if (isLoadMore) _isLoadingMore.value = false;
          return;
        }

        if (!isLoadMore) {
          historyList.clear(); // Clear existing data only on initial load
          _currentPage = 1;
          _hasMore = true;
        }

        // Add new items to the list
        for (var element in value.data.history) {
          historyList.add(
            History(
              id: element.id,
              vendorId: element.vendorId,
              branchId: element.branchId,
              approvedBy: element.approvedBy,
              approvedAt: element.approvedAt,
              carId: element.carId,
              userId: element.userId,
              slug: element.slug,
              phone: element.phone,
              email: element.email,
              tripId: element.tripId,
              message: element.message,
              distance: element.distance,
              createdAt: element.createdAt,
              updatedAt: element.updatedAt,
              status: element.status,
              amount: element.amount,
              destination: element.destination,
              location: element.location,
              paymentType: element.paymentType,
              pickupDate: element.pickupDate,
              pickupTime: element.pickupTime,
              roundPickupDate: element.roundPickupDate,
              roundPickupTime: element.roundPickupTime,
              rentalDays: element.rentalDays,
              charges: element.charges,
              trxId: element.trxId,
              isDeliver: element.isDeliver,
              cars: element.cars,
              vendorInfo: element.vendorInfo,
            ),
          );
        }

        // Check if there are more items to load
        // If we received less items than perPage, there are no more items
        if (value.data.history.length < _perPage) {
          _hasMore = false;
        } else {
          _currentPage++;
        }

        if (isLoadMore) _isLoadingMore.value = false;
      },
    );
  }

  void loadMore() {
    if (!_hasMore || _isLoadingMore.value) return;
    getHistoryInfo(isLoadMore: true);
  }

  Future<void> refresh() async {
    _currentPage = 1;
    _hasMore = true;
    await getHistoryInfo();
  }
}
