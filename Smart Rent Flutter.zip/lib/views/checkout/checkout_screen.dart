import 'package:carbo/base/utils/basic_import.dart';
import 'package:carbo/views/checkout/controller/checkout_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:form_builder_validators/form_builder_validators.dart';

class CheckoutScreen extends StatelessWidget {
  const CheckoutScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(CheckoutController());
    return Scaffold(
      appBar: CustomAppBar('Checkout'),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(Dimensions.paddingSize),
        child: Form(
          key: controller.formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextWidget(
                'Payment Details',
                style: CustomStyle.headlineSmall,
              ),
              SizedBox(height: Dimensions.heightSize),
              
              // Card Holder Name
              PrimaryInputWidget(
                controller: controller.cardHolderNameController,
                hintText: 'Card Holder Name',
                label: 'Name on Card',
                validatorFunction: FormBuilderValidators.required(),
              ),
              SizedBox(height: Dimensions.heightSize),

              // Card Number
              PrimaryInputWidget(
                controller: controller.cardNumberController,
                hintText: '0000 0000 0000 0000',
                label: 'Card Number',
                textInputType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(16),
                  _CardNumberFormatter(),
                ],
                validatorFunction: FormBuilderValidators.compose([
                  FormBuilderValidators.required(),
                  FormBuilderValidators.creditCard(),
                ]),
              ),
              SizedBox(height: Dimensions.heightSize),

              Row(
                children: [
                  // Expiry Date
                  Expanded(
                    child: PrimaryInputWidget(
                      controller: controller.expiryDateController,
                      hintText: 'MM/YY',
                      label: 'Expiry Date',
                      textInputType: TextInputType.datetime,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(4),
                        _ExpiryDateFormatter(),
                      ],
                      validatorFunction: FormBuilderValidators.required(),
                    ),
                  ),
                  SizedBox(width: Dimensions.widthSize),
                  
                  // CVV
                  Expanded(
                    child: PrimaryInputWidget(
                      controller: controller.cvvController,
                      hintText: '123',
                      label: 'CVV',
                      textInputType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(4),
                      ],
                      validatorFunction: FormBuilderValidators.compose([
                        FormBuilderValidators.required(),
                        FormBuilderValidators.minLength(3),
                      ]),
                    ),
                  ),
                ],
              ),
              
              SizedBox(height: Dimensions.heightSize * 2),
              
              Obx(() => controller.isLoading.value
                  ? const Center(child: CircularProgressIndicator())
                  : PrimaryButton(
                      title: 'Pay ${controller.amount} SAR',
                      onPressed: controller.processPayment,
                    )),
            ],
          ),
        ),
      ),
    );
  }
}

class _CardNumberFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    var text = newValue.text;
    if (newValue.selection.baseOffset == 0) {
      return newValue;
    }
    var buffer = StringBuffer();
    for (int i = 0; i < text.length; i++) {
      buffer.write(text[i]);
      var nonZeroIndex = i + 1;
      if (nonZeroIndex % 4 == 0 && nonZeroIndex != text.length) {
        buffer.write(' ');
      }
    }
    var string = buffer.toString();
    return newValue.copyWith(
      text: string,
      selection: TextSelection.collapsed(offset: string.length),
    );
  }
}

class _ExpiryDateFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    var text = newValue.text;
    if (newValue.selection.baseOffset == 0) {
      return newValue;
    }
    var buffer = StringBuffer();
    for (int i = 0; i < text.length; i++) {
      buffer.write(text[i]);
      var nonZeroIndex = i + 1;
      if (nonZeroIndex % 2 == 0 && nonZeroIndex != text.length) {
        buffer.write('/');
      }
    }
    var string = buffer.toString();
    return newValue.copyWith(
      text: string,
      selection: TextSelection.collapsed(offset: string.length),
    );
  }
}
