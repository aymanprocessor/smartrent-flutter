import 'dart:convert';
import 'package:carbo/services/moyasar_payment_service.dart';
import 'package:carbo/base/utils/basic_import.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

class CheckoutController extends GetxController {
  final formKey = GlobalKey<FormState>();
  final cardNumberController = TextEditingController();
  final cardHolderNameController = TextEditingController();
  final expiryDateController = TextEditingController();
  final cvvController = TextEditingController();

  RxBool isLoading = false.obs;
  
  // Payment Config
  final String publishableKey = 'pk_test_rmk7ngoM4JMgkxbHJkr8ogXXV6nedsJsjSNhc8SA';
  
  // Transaction details
  double amount = 0.0;
  String description = '';
  String mode = 'payment'; // 'payment' or 'tokenization'
  
  @override
  void onInit() {
    super.onInit();
    if (Get.arguments != null) {
      amount = double.tryParse(Get.arguments['amount'].toString()) ?? 0.0;
      description = Get.arguments['description'] ?? 'Booking Payment';
      mode = Get.arguments['mode'] ?? 'payment';
    }
  }

  Future<void> processPayment() async {
    if (!formKey.currentState!.validate()) return;

    isLoading.value = true;

    try {
      // 1. Tokenize Card
      // Using direct Moyasar API for tokenization to ensure control over the flow
      // as we need to send the token to our backend.
      
      final expiry = expiryDateController.text.split('/');
      if (expiry.length != 2) {
        CustomSnackBar.error('Invalid expiry date format');
        isLoading.value = false;
        return;
      }

      final month = expiry[0];
      final year = expiry[1]; // Assuming YY format, Moyasar might need YYYY or YY. API usually takes what is on card.
      // If YY, API usually handles it, or we can prepend 20. Let's assume user enters MM/YY.

      final cardData = {
        'name': cardHolderNameController.text,
        'number': cardNumberController.text.replaceAll(' ', ''),
        'cvc': cvvController.text,
        'month': month,
        'year': year,
        'save_only': 'true',
      };
      
      final tokenResponse = await http.post(
        Uri.parse('https://api.moyasar.com/v1/tokens'),
        headers: {
          'Authorization': 'Basic ${base64Encode(utf8.encode('$publishableKey:'))}',
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: cardData,
      );

      if (tokenResponse.statusCode != 200 && tokenResponse.statusCode != 201) {
        final error = jsonDecode(tokenResponse.body);
        throw Exception(error['message'] ?? 'Tokenization failed');
      }

      final tokenData = jsonDecode(tokenResponse.body);
      final String token = tokenData['id'];

      if (mode == 'tokenization') {
        isLoading.value = false;
        // Use Navigator to avoid GetX Snackbar conflict
        Navigator.of(Get.context!).pop({'token': token});
        return;
      }

      // 2. Send Token to Backend
      final result = await MoyasarPaymentService.processPayment(
        token: token,
        amount: amount,
        currency: 'SAR',
        description: description,
        callbackUrl: 'https://smartrent.sa/payment/callback', 
      );

      if (result != null) {
        // 3. Handle 3DS or Success
        if (result['status'] == 'initiated' && result['transaction_url'] != null) {
           // Open WebView for 3DS
           final webViewResult = await Get.to(() => PaymentWebView(url: result['transaction_url']));
           if (webViewResult == true) {
             Get.back(result: {'success': true});
           }
        } else if (result['status'] == 'paid') {
           CustomSnackBar.success(title: 'Success', message: 'Payment successful');
           Get.back(result: {'success': true});
        } else {
           CustomSnackBar.error('Payment status: ${result['status']}');
        }
      }

    } catch (e) {
      CustomSnackBar.error(e.toString());
    } finally {
      isLoading.value = false;
    }
  }
}

class PaymentWebView extends StatelessWidget {
  final String url;
  const PaymentWebView({Key? key, required this.url}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar('3D Secure Verification'),
      body: InAppWebView(
        initialUrlRequest: URLRequest(url: WebUri(url)),
        onWebViewCreated: (controller) {},
        onLoadStop: (controller, url) async {
          if (url != null) {
             // Check for callback URL or success/failure indicators
             // This depends on how the backend handles the callback.
             // Usually, the backend will redirect to the callback_url with status.
             if (url.toString().contains('payment/callback')) {
               // Verify payment status again or just close and show success
               // Ideally, call an endpoint to check status.
               // For now, we'll just close and let the user know.
               Get.back(result: true);
               CustomSnackBar.success(title: 'Success', message: 'Verification completed');
             }
          }
        },
      ),
    );
  }
}
