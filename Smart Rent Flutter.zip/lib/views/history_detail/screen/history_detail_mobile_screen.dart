part of 'history_detail_screen.dart';

class HistoryDetailMobileScreen extends StatelessWidget {
  const HistoryDetailMobileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Get arguments - can be either direct history object or historyId from notification
    final args = Get.arguments as Map<String, dynamic>?;
    
    if (args == null) {
      return Scaffold(
        appBar: AppBar(title: const TextWidget('Booking Details')),
        body: const Center(child: TextWidget('No booking data provided')),
      );
    }

    // Try to get history object first, then fall back to historyId
    History? history = args['history'];
    final int? historyId = args['historyId'];

    // If we only have historyId, fetch from controller
    if (history == null && historyId != null) {
      final controller = Get.find<HistoryController>();
      history = controller.historyList.firstWhereOrNull((h) => h.id == historyId);
    }

    if (history == null) {
      return Scaffold(
        appBar: AppBar(
          title: const TextWidget(
            'Booking Details',
            typographyStyle: TypographyStyle.titleMedium,
            fontWeight: FontWeight.w700,
          ),
          centerTitle: true,
          elevation: 1,
        ),
        body: const Center(
          child: TextWidget('Booking not found'),
        ),
      );
    }

    return Scaffold(
      backgroundColor: CustomColor.whiteColor,
      appBar: AppBar(
        title: const TextWidget(
          'Booking Details',
          typographyStyle: TypographyStyle.titleMedium,
          fontWeight: FontWeight.w700,
        ),
        centerTitle: true,
        elevation: 1,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(Dimensions.paddingSize),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Status Card
            _buildStatusCard(history),
            Sizes.height.v20,

            // Car Details Section
            _buildSectionCard(
              'Car Details',
              [
                _buildInfoRow('Car Model', history.cars.carModel ?? 'N/A', Icons.directions_car),
                _buildInfoRow('Car Type', history.cars.carType ?? 'N/A', Icons.category),
                _buildInfoRow('Car Number', history.cars.carNumber ?? 'N/A', Icons.confirmation_number),
              ],
            ),
            Sizes.height.v15,

            // Trip Details Section
            _buildSectionCard(
              'Trip Details',
              [
                _buildInfoRow('Pickup Location', history.location ?? 'N/A', Icons.location_on),
                _buildInfoRow('Destination', history.destination ?? 'N/A', Icons.flag),
                _buildInfoRow('Pickup Date', _formatDate(history.pickupDate), Icons.calendar_today),
                _buildInfoRow('Pickup Time', history.pickupTime, Icons.access_time),
                if (history.roundPickupDate != null)
                  _buildInfoRow('Return Date', history.roundPickupDate!, Icons.event_repeat),
                if (history.roundPickupTime != null)
                  _buildInfoRow('Return Time', history.roundPickupTime!, Icons.schedule),
                _buildInfoRow('Distance', '${history.distance} km', Icons.straighten),
                _buildInfoRow('Rental Days', '${history.rentalDays} day${history.rentalDays != 1 ? 's' : ''}', Icons.event_available),
                if (history.isDeliver != null)
                  _buildInfoRow('Delivery', history.isDeliver! ? 'Yes' : 'No', Icons.delivery_dining),
              ],
            ),
            Sizes.height.v15,

            // Payment Details Section
            _buildSectionCard(
              'Payment Details',
              [
                _buildInfoRow('Amount', '${history.amount} ${BasicServices.baseCurCode}', Icons.attach_money),
                if (history.charges != null)
                  _buildInfoRow('Charges', '${history.charges} ${BasicServices.baseCurCode}', Icons.receipt),
                _buildInfoRow('Payment Type', history.paymentType, Icons.payment),
                if (history.trxId != null)
                  _buildInfoRow('Transaction ID', history.trxId!, Icons.tag),
              ],
            ),
            Sizes.height.v15,

            // Contact Details Section
            if (history.phone != null || history.email != null)
              _buildSectionCard(
                'Contact Details',
                [
                  if (history.phone != null)
                    _buildInfoRow('Phone', history.phone!, Icons.phone),
                  if (history.email != null)
                    _buildInfoRow('Email', history.email!, Icons.email),
                ],
              ),
            if (history.phone != null || history.email != null)
              Sizes.height.v15,

            // Additional Information Section
            if (history.message.isNotEmpty)
              _buildSectionCard(
                'Message',
                [
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.all(Dimensions.paddingSize * 0.8),
                    decoration: BoxDecoration(
                      color: CustomColor.typography.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(Dimensions.radius * 0.8),
                    ),
                    child: TextWidget(
                      history.message,
                      typographyStyle: TypographyStyle.bodySmall,
                    ),
                  ),
                ],
              ),
            if (history.message.isNotEmpty)
              Sizes.height.v15,

            // Booking Information Section
            _buildSectionCard(
              'Booking Information',
              [
                _buildInfoRow('Booking ID', '#${history.id}', Icons.bookmark),
                if (history.slug != null)
                  _buildInfoRow('Reference', history.slug!, Icons.receipt_long),
                _buildInfoRow('Created At', _formatDateTime(history.createdAt), Icons.access_time),
                _buildInfoRow('Updated At', _formatDateTime(history.updatedAt), Icons.update),
                if (history.approvedBy != null)
                  _buildInfoRow('Approved By', history.approvedBy!, Icons.verified_user),
                if (history.approvedAt != null)
                  _buildInfoRow('Approved At', _formatDateTime(history.approvedAt!), Icons.check_circle),
              ],
            ),
            Sizes.height.v20,
          ],
        ),
      ),
    );
  }

  Widget _buildStatusCard(History history) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(Dimensions.paddingSize),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            _getStatusColor(history.status),
            _getStatusColor(history.status).withOpacity(0.7),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(Dimensions.radius * 1.2),
        boxShadow: [
          BoxShadow(
            color: _getStatusColor(history.status).withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(
            _getStatusIcon(history.status),
            size: 48,
            color: CustomColor.whiteColor,
          ),
          Sizes.height.v10,
          TextWidget(
            _getStatusText(history.status),
            typographyStyle: TypographyStyle.titleMedium,
            color: CustomColor.whiteColor,
            fontWeight: FontWeight.w700,
          ),
          Sizes.height.v5,
          TextWidget(
            'Booking Status',
            typographyStyle: TypographyStyle.bodySmall,
            color: CustomColor.whiteColor.withOpacity(0.9),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionCard(String title, List<Widget> children) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(Dimensions.paddingSize),
      decoration: BoxDecoration(
        color: CustomColor.whiteColor,
        borderRadius: BorderRadius.circular(Dimensions.radius * 1.2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextWidget(
            title,
            typographyStyle: TypographyStyle.titleMedium,
            fontWeight: FontWeight.w700,
          ),
          Sizes.height.v10,
          ...children,
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value, IconData icon) {
    return Padding(
      padding: EdgeInsets.only(bottom: Dimensions.verticalSize * 0.8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            icon,
            size: 18,
            color: CustomColor.typography.withOpacity(0.6),
          ),
          Sizes.width.v10,
          Expanded(
            flex: 2,
            child: TextWidget(
              label,
              typographyStyle: TypographyStyle.bodySmall,
              color: CustomColor.typography.withOpacity(0.6),
            ),
          ),
          Expanded(
            flex: 3,
            child: TextWidget(
              value,
              typographyStyle: TypographyStyle.bodySmall,
              fontWeight: FontWeight.w600,
              textAlign: TextAlign.end,
            ),
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(int status) {
    switch (status) {
      case 1:
        return Colors.orange;
      case 2:
        return Colors.blue;
      case 3:
        return CustomColor.primary;
      case 4:
        return CustomColor.rejected;
      default:
        return Colors.grey;
    }
  }

  IconData _getStatusIcon(int status) {
    switch (status) {
      case 1:
        return Icons.hourglass_empty;
      case 2:
        return Icons.directions_car;
      case 3:
        return Icons.check_circle;
      case 4:
        return Icons.cancel;
      default:
        return Icons.help_outline;
    }
  }

  String _getStatusText(int status) {
    switch (status) {
      case 1:
        return Strings.pending;
      case 2:
        return Strings.ongoing;
      case 3:
        return Strings.complete;
      case 4:
        return Strings.reject;
      default:
        return 'Unknown';
    }
  }

  String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
  }

  String _formatDateTime(DateTime dateTime) {
    return '${_formatDate(dateTime)} at ${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
  }
}
