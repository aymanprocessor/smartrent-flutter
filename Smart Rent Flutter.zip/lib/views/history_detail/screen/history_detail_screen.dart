import 'package:flutter/material.dart';
import '../../../base/utils/basic_import.dart';
import '../../../base/api/services/basic_services.dart';
import '../../history/model/history_model.dart';
import '../../history/controller/history_controller.dart';
part 'history_detail_mobile_screen.dart';
part 'history_detail_tablet_screen.dart';

class HistoryDetailScreen extends StatelessWidget {
  const HistoryDetailScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ResponsiveLayout(
      mobile: HistoryDetailMobileScreen(),
      tablet: HistoryDetailTabletScreen(),
    );
  }
}
