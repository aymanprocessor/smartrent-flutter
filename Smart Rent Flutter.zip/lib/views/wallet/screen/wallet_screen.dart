import 'package:flutter/material.dart';
import 'package:carbo/base/utils/responsive_layout.dart';
import 'wallet_mobile_screen.dart';
import 'wallet_tablet_screen.dart';

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const ResponsiveLayout(
      mobile: WalletMobileScreen(),
      tablet: WalletTabletScreen(),
    );
  }
}
