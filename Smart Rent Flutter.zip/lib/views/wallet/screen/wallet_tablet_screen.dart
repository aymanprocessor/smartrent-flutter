import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:carbo/controllers/wallet_controller.dart';
import 'package:carbo/generated/l10n/app_localizations.dart';
import '../widget/balance_card_widget.dart';
import '../widget/topup_button_widget.dart';
import '../widget/transactions_header_widget.dart';
import '../widget/transactions_list_widget.dart';

class WalletTabletScreen extends GetView<WalletController> {
  const WalletTabletScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context)!.appLMyWallet),
        centerTitle: true,
      ),
      body: RefreshIndicator(
        onRefresh: controller.refresh,
        child: Center(
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxWidth: MediaQuery.of(context).size.width > 900 ? 0.8.sw : 0.9.sw,
            ),
            child: CustomScrollView(
              slivers: [
                SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16.w),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 24.h),
                        Text(
                          AppLocalizations.of(context)!.appLWalletBalance,
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        SizedBox(height: 16.h),
                        BalanceCardWidget(controller: controller),
                        SizedBox(height: 32.h),
                        Row(
                          children: [
                            Expanded(
                              child: TopUpButtonWidget(
                                controller: controller,
                                context: context,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 32.h),
                        TransactionsHeaderWidget(controller: controller),
                        SizedBox(height: 16.h),
                      ],
                    ),
                  ),
                ),
                TransactionsListWidget(controller: controller),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
