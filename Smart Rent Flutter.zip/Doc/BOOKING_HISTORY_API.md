# Booking History API Documentation

This document describes the paginated booking history endpoints for user and vendor roles, optimized for mobile lazy-loading patterns.

## Overview

Both endpoints support pagination with query parameters `page` and `per_page`, returning booking records in a mobile-friendly format with separate data array and pagination metadata.

---

## User Booking History

### Endpoint

```
GET /api/v1/user/car-booking/booking/history
```

### Authentication

-   Required: Yes
-   Guard: `api` (Laravel Passport token)
-   Middleware: `auth:api`

### Query Parameters

| Parameter | Type    | Required | Default | Max | Description                 |
| --------- | ------- | -------- | ------- | --- | --------------------------- |
| page      | integer | No       | 1       | -   | Current page number         |
| per_page  | integer | No       | 5       | 50  | Number of bookings per page |

### Request Example

```http
GET /api/v1/user/car-booking/history?page=1&per_page=10
Authorization: Bearer YOUR_API_TOKEN
```

### Response Structure

#### Success Response (200)

```json
{
    "message": {
        "success": ["History fetched successfully!"]
    },
    "data": {
        "history": [
            {
                "id": 123,
                "user_id": 45,
                "destination_from": "City Center",
                "destination_to": "Airport",
                "pickup_date": "2025-12-15",
                "pickup_time": "10:00:00",
                "credentials": {
                    "round_pickup_date": "2025-12-20",
                    "round_pickup_time": "15:00:00"
                },
                "status": 3,
                "created_at": "2025-12-13T08:30:00.000000Z",
                "cars": {
                    "id": 78,
                    "name": "Toyota Camry 2024",
                    "vendor_id": 12,
                    "vendor": {
                        "id": 12,
                        "firstname": "Ahmed",
                        "business_name": "Premium Rentals"
                    }
                }
            }
        ],
        "pagination": {
            "current_page": 1,
            "per_page": 10,
            "total": 45,
            "total_pages": 5,
            "from": 1,
            "to": 10,
            "has_more": true
        }
    },
    "type": "success"
}
```

#### Error Response (422) - Validation Failed

```json
{
    "message": {
        "error": ["The per_page must not be greater than 50."]
    },
    "type": "error"
}
```

#### Error Response (401) - Unauthorized

```json
{
    "message": "Unauthenticated."
}
```

### Notes

-   The `cars.car_number` and `cars.experience` fields are hidden from the response for security
-   Bookings are ordered by `created_at` descending (newest first)
-   Empty result returns `history: []` with `total: 0`

---

## Vendor Booking History

### Endpoint

```
GET /api/v1/vendor/history/view
```

### Authentication

-   Required: Yes
-   Guard: `vendor_api` (Laravel Passport vendor token)
-   Middleware: `auth:vendor_api`

### Query Parameters

| Parameter | Type    | Required | Default | Max | Description                 |
| --------- | ------- | -------- | ------- | --- | --------------------------- |
| page      | integer | No       | 1       | -   | Current page number         |
| per_page  | integer | No       | 5       | 50  | Number of bookings per page |

### Request Example

```http
GET /api/v1/vendor/history/view?page=2&per_page=5
Authorization: Bearer YOUR_VENDOR_API_TOKEN
```

### Response Structure

#### Success Response (200) - With Data

```json
{
    "message": {
        "success": ["History fetch successfully"]
    },
    "data": {
        "booking_history": [
            {
                "id": 456,
                "user_id": 89,
                "destination_from": "Downtown",
                "destination_to": "Hotel Plaza",
                "pickup_date": "2025-12-10",
                "pickup_time": "14:00:00",
                "status": 3,
                "created_at": "2025-12-09T12:00:00.000000Z",
                "cars": {
                    "id": 34,
                    "name": "Honda Accord",
                    "vendor_id": 12,
                    "branch_id": 2
                }
            }
        ],
        "pagination": {
            "current_page": 2,
            "per_page": 5,
            "total": 23,
            "total_pages": 5,
            "from": 6,
            "to": 10,
            "has_more": true
        },
        "image-path": {
            "base_url": "https://yourapp.com",
            "image_path": "site-section"
        }
    },
    "type": "success"
}
```

#### Success Response (200) - Empty Results

```json
{
    "message": {
        "success": ["No booking history found"]
    },
    "data": {
        "booking_history": [],
        "pagination": {
            "current_page": 1,
            "per_page": 5,
            "total": 0,
            "total_pages": 0,
            "from": null,
            "to": null,
            "has_more": false
        },
        "image-path": {
            "base_url": "https://yourapp.com",
            "image_path": "site-section"
        }
    },
    "type": "success"
}
```

#### Error Response (422) - Validation Failed

```json
{
    "message": {
        "error": ["The page must be at least 1."]
    },
    "type": "error"
}
```

### Filtering Logic

-   Returns bookings with `status` 3 (completed) or 4 (rejected)
-   Filters by vendor's cars (based on `vendor_id`)
-   For vendor employees: additionally filters by `branch_id`
-   Bookings ordered by `id` descending

### Notes

-   The `image-path` provides base URL and path for car images
-   Owner vendors see all bookings for their company
-   Employee vendors see only bookings for their assigned branch

---

## Mobile Lazy Loading Implementation

### Flutter/React Native Example

```dart
// Dart/Flutter example
class BookingHistoryScreen extends StatefulWidget {
  @override
  _BookingHistoryScreenState createState() => _BookingHistoryScreenState();
}

class _BookingHistoryScreenState extends State<BookingHistoryScreen> {
  List<Booking> bookings = [];
  int currentPage = 1;
  bool hasMore = true;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    loadBookings();
  }

  Future<void> loadBookings() async {
    if (isLoading || !hasMore) return;

    setState(() => isLoading = true);

    final response = await api.get(
      '/api/v1/user/car-booking/history',
      queryParameters: {'page': currentPage, 'per_page': 5},
    );

    if (response.data['type'] == 'success') {
      final data = response.data['data'];
      setState(() {
        bookings.addAll(data['history'].map((b) => Booking.fromJson(b)));
        hasMore = data['pagination']['has_more'];
        currentPage++;
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: bookings.length + (hasMore ? 1 : 0),
      itemBuilder: (context, index) {
        if (index == bookings.length) {
          loadBookings(); // Load more when reaching end
          return CircularProgressIndicator();
        }
        return BookingCard(booking: bookings[index]);
      },
    );
  }
}
```

### JavaScript/React Example

```javascript
// React example with infinite scroll
import { useState, useEffect, useRef } from "react";

export default function BookingHistory() {
    const [bookings, setBookings] = useState([]);
    const [page, setPage] = useState(1);
    const [hasMore, setHasMore] = useState(true);
    const [loading, setLoading] = useState(false);
    const observer = useRef();

    const loadMore = async () => {
        if (loading || !hasMore) return;

        setLoading(true);
        const response = await fetch(
            `/api/v1/user/car-booking/history?page=${page}&per_page=5`,
            { headers: { Authorization: `Bearer ${token}` } }
        );

        const json = await response.json();
        if (json.type === "success") {
            setBookings((prev) => [...prev, ...json.data.history]);
            setHasMore(json.data.pagination.has_more);
            setPage((prev) => prev + 1);
        }
        setLoading(false);
    };

    useEffect(() => {
        loadMore();
    }, []);

    const lastBookingRef = useCallback(
        (node) => {
            if (loading) return;
            if (observer.current) observer.current.disconnect();
            observer.current = new IntersectionObserver((entries) => {
                if (entries[0].isIntersecting && hasMore) {
                    loadMore();
                }
            });
            if (node) observer.current.observe(node);
        },
        [loading, hasMore]
    );

    return (
        <div>
            {bookings.map((booking, index) => (
                <div
                    key={booking.id}
                    ref={index === bookings.length - 1 ? lastBookingRef : null}
                >
                    <BookingCard booking={booking} />
                </div>
            ))}
            {loading && <div>Loading...</div>}
        </div>
    );
}
```

---

## Status Codes

| Status | Meaning         |
| ------ | --------------- |
| 1      | Pending         |
| 2      | Active/Accepted |
| 3      | Completed       |
| 4      | Rejected        |

---

## Implementation Details

### Changes from Previous Version

-   **Added**: `page` and `per_page` query parameters
-   **Changed**: Response now includes separate `pagination` object instead of full collection
-   **Changed**: Data array is now under `history` or `booking_history` key (not a paginator object)
-   **Fixed**: Vendor endpoint now correctly filters by status using `whereIn([3,4])` instead of buggy `orWhere`

### Performance Considerations

-   Default `per_page=5` optimized for mobile bandwidth
-   Maximum `per_page=50` to prevent server overload
-   Indexed queries on `user_id`, `vendor_id`, and `status` columns recommended
-   Consider caching for vendors with high booking volume

### Migration Notes for Existing Clients

If you have existing mobile clients expecting unpaginated arrays:

1. Update to read `data.history` instead of direct array
2. Add pagination support using `data.pagination.has_more`
3. Send `per_page=100` (or higher) as temporary workaround if lazy loading cannot be implemented immediately
4. Long-term: implement proper pagination to improve performance

---

## Related Documentation

-   [Car Booking Flow Guide](CAR_BOOKING_FLOW_GUIDE.md)
-   [Car Booking API Quick Reference](CAR_BOOKING_API_QUICK_REFERENCE.md)
-   [Booking Token Explained](BOOKING_TOKEN_EXPLAINED.md)
